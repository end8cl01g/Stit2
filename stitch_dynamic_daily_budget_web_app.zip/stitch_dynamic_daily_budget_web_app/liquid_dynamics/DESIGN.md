---
name: Liquid Dynamics
colors:
  surface: '#10131b'
  surface-dim: '#10131b'
  surface-bright: '#363942'
  surface-container-lowest: '#0b0e16'
  surface-container-low: '#181c23'
  surface-container: '#1c2028'
  surface-container-high: '#272a32'
  surface-container-highest: '#31353d'
  on-surface: '#e0e2ed'
  on-surface-variant: '#c1c6d7'
  inverse-surface: '#e0e2ed'
  inverse-on-surface: '#2d3039'
  outline: '#8b90a0'
  outline-variant: '#414755'
  surface-tint: '#adc6ff'
  primary: '#adc6ff'
  on-primary: '#002e69'
  primary-container: '#4b8eff'
  on-primary-container: '#00285c'
  inverse-primary: '#005bc1'
  secondary: '#40dfd2'
  on-secondary: '#003733'
  secondary-container: '#00c3b6'
  on-secondary-container: '#004a45'
  tertiary: '#ffb95a'
  on-tertiary: '#462a00'
  tertiary-container: '#c68315'
  on-tertiary-container: '#3d2400'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#d8e2ff'
  primary-fixed-dim: '#adc6ff'
  on-primary-fixed: '#001a41'
  on-primary-fixed-variant: '#004493'
  secondary-fixed: '#62f9eb'
  secondary-fixed-dim: '#3cdccf'
  on-secondary-fixed: '#00201d'
  on-secondary-fixed-variant: '#00504a'
  tertiary-fixed: '#ffddb6'
  tertiary-fixed-dim: '#ffb95a'
  on-tertiary-fixed: '#2a1800'
  on-tertiary-fixed-variant: '#643f00'
  background: '#10131b'
  on-background: '#e0e2ed'
  surface-variant: '#31353d'
typography:
  hero-number:
    fontFamily: Inter
    fontSize: 64px
    fontWeight: '700'
    lineHeight: '1.1'
    letterSpacing: -0.04em
  hero-number-mobile:
    fontFamily: Inter
    fontSize: 48px
    fontWeight: '700'
    lineHeight: '1.1'
    letterSpacing: -0.04em
  headline-lg:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-caps:
    fontFamily: Space Grotesk
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.1em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 8px
  container-padding: 24px
  gutter: 16px
  stack-sm: 8px
  stack-md: 16px
  stack-lg: 32px
---

## Brand & Style

This design system embodies a "Minimalist Cyber-Organic" aesthetic, moving away from static financial spreadsheets toward a living, breathing guidance system. The brand personality is sophisticated, futuristic, and adaptive. It seeks to evoke a sense of calm control through "Liquid Dynamics"—where data flows and ebbs like a natural element rather than a rigid set of constraints.

The visual style utilizes high-end minimalism mixed with glassmorphism. It relies on deep obsidian voids and vibrant, bio-luminescent gradients to signal financial health. Every interaction should feel intentional and haptic-inspired, prioritizing a fluid emotional response over raw data density.

## Colors

The palette is centered on a dark-mode "Deep Obsidian" foundation to allow "Cyber-Organic" elements to glow. 

- **Primary (Oxygen Blue):** Used for stable states, active navigation, and primary CTAs.
- **Positive State (Calm Teal):** A transitionary color for positive balances and "on-track" budgeting.
- **Warning State (Warm Amber):** Used for nearing budget limits or pending transactions.
- **Overspent (Soft Coral):** A gentle but clear indicator of exceeding a quota.

Gradients should be used sparingly but impactfully, specifically a linear flow from `primary` to `secondary` to represent financial growth.

## Typography

The typography system prioritizes the "Hero Number"—the daily budget. This is rendered in high-contrast Inter with tight kerning to feel like a premium instrument. 

- **Headlines:** Use Inter with semi-bold weights for a modern, tech-forward look.
- **Labels:** Space Grotesk is used for secondary data points and metadata to add a subtle "technical/futuristic" flavor without sacrificing legibility.
- **Scale:** Sizes are generous to ensure the UI feels airy and un-crowded.

## Layout & Spacing

The layout follows a fluid-to-fixed model. On mobile, it utilizes a safe-area-aware 4-column grid with generous 24px margins to avoid edge-tension. On desktop/tablet, it centers content within a 12-column grid.

Spacing is driven by an 8px rhythm. However, "Liquid Dynamics" requires significant white space (negative space) between functional groups to maintain the minimalist aesthetic. Containers should have dynamic internal padding that scales with the size of the glassmorphic card.

## Elevation & Depth

Depth is conveyed through **Glassmorphism** and **Ambient Glows**. 

- **Surface Tiers:** Background is a flat #0A0A0A. Primary cards use a semi-transparent blur (Backdrop Filter: 20px) with a 1px thin-line stroke (White at 10% opacity) to define edges.
- **Shadows:** No traditional black shadows. Instead, use a subtle "Oxygen Blue" or "Calm Teal" ambient glow (30px-60px blur, 5-10% opacity) positioned behind active budget cards to simulate bio-luminescence.
- **Interactions:** When an element is pressed, it should appear to "sink" into the background, reducing its blur and increasing its saturation.

## Shapes

The shape language is organic and soft. Standard cards and containers use a 1rem (16px) radius to feel approachable. Interactive elements like buttons use the `rounded-xl` or "Pill" treatment to contrast against the more structured layout containers. 

Avoid sharp 90-degree corners entirely to maintain the "liquid" feel of the interface.

## Components

- **Buttons:** Primary buttons are pill-shaped with a subtle gradient from Oxygen Blue to Calm Teal. Text is centered, semi-bold.
- **Glass Cards:** The primary vessel for data. Features a 10% white border and a 20px background blur. Content within cards should have 24px internal padding.
- **Daily Progress (Liquid Gauge):** A custom component instead of a standard bar chart. A wavy, animated "liquid" level that fills a container to represent remaining daily budget.
- **Inputs:** Minimalist bottom-aligned strokes that glow when focused. No heavy boxes.
- **Chips:** Small, pill-shaped tags used for categories (e.g., "Food," "Transport") with low-opacity background tints matching the category's assigned glow.
- **Haptic Sliders:** For adjusting budget goals, featuring a thick track and a glow-pulse on the thumb handle during movement.