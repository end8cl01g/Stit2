---
name: Neon Protocol
colors:
  surface: '#131318'
  surface-dim: '#131318'
  surface-bright: '#39383e'
  surface-container-lowest: '#0e0e13'
  surface-container-low: '#1b1b20'
  surface-container: '#1f1f25'
  surface-container-high: '#2a292f'
  surface-container-highest: '#35343a'
  on-surface: '#e4e1e9'
  on-surface-variant: '#b9cacb'
  inverse-surface: '#e4e1e9'
  inverse-on-surface: '#303036'
  outline: '#849495'
  outline-variant: '#3b494b'
  surface-tint: '#00dbe9'
  primary: '#dbfcff'
  on-primary: '#00363a'
  primary-container: '#00f0ff'
  on-primary-container: '#006970'
  inverse-primary: '#006970'
  secondary: '#ffb2b8'
  on-secondary: '#67001d'
  secondary-container: '#ff506e'
  on-secondary-container: '#5b0018'
  tertiary: '#e1ffd1'
  on-tertiary: '#053900'
  tertiary-container: '#33fb0a'
  on-tertiary-container: '#106e00'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#7df4ff'
  primary-fixed-dim: '#00dbe9'
  on-primary-fixed: '#002022'
  on-primary-fixed-variant: '#004f54'
  secondary-fixed: '#ffdadb'
  secondary-fixed-dim: '#ffb2b8'
  on-secondary-fixed: '#40000f'
  on-secondary-fixed-variant: '#91002d'
  tertiary-fixed: '#79ff5b'
  tertiary-fixed-dim: '#2ae500'
  on-tertiary-fixed: '#022100'
  on-tertiary-fixed-variant: '#095300'
  background: '#131318'
  on-background: '#e4e1e9'
  surface-variant: '#35343a'
typography:
  headline-xl:
    fontFamily: Space Grotesk
    fontSize: 48px
    fontWeight: '700'
    lineHeight: '1.1'
    letterSpacing: 0.05em
  headline-lg:
    fontFamily: Space Grotesk
    fontSize: 32px
    fontWeight: '700'
    lineHeight: '1.2'
    letterSpacing: 0.05em
  headline-md:
    fontFamily: Space Grotesk
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.2'
    letterSpacing: 0.02em
  body-lg:
    fontFamily: JetBrains Mono
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: JetBrains Mono
    fontSize: 14px
    fontWeight: '400'
    lineHeight: '1.5'
  label-md:
    fontFamily: Space Mono
    fontSize: 12px
    fontWeight: '500'
    lineHeight: '1'
    letterSpacing: 0.1em
  headline-lg-mobile:
    fontFamily: Space Grotesk
    fontSize: 28px
    fontWeight: '700'
    lineHeight: '1.2'
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  unit: 4px
  gutter: 16px
  margin-mobile: 16px
  margin-desktop: 32px
  container-max: 1200px
---

## Brand & Style
The design system embodies a high-fidelity Cyberpunk / Neon-noir aesthetic, designed for high-performance productivity in a high-stakes digital environment. It merges the raw, industrial feel of Brutalism with the ethereal depth of Glassmorphism. The interface should feel like a localized "Neural HUD"—utilitarian, hyper-legible, yet vibrating with synthetic energy.

Key principles include:
- **Technical Precision:** Use of monospaced fonts and grid-aligned elements to suggest an engineered environment.
- **Atmospheric Depth:** Layered translucent surfaces and backdrop blurs to simulate a multi-dimensional terminal.
- **Luminous Feedback:** Utilizing neon glows and pulsing animations to indicate life-signs and system urgency.
- **Digital Grain:** Implementation of scanline overlays and subtle noise to prevent the UI from feeling too "sterile."

## Colors
The palette is rooted in a "Deep Space" black (`#0A0A0F`), providing a void-like canvas for high-chroma neon accents. 

- **Primary (Cyan):** Used for data visualization, active states, and structural wireframes. It represents the "standard" operating state.
- **Danger/Urgency (Magenta):** Reserved for critical tasks, over-due deadlines, and destructive actions.
- **Success (Toxic Green):** Indicates task completion, system health, and secure connections.
- **Warning (Yellow):** Highlights pending items or low-priority alerts.

All interactive elements should utilize a `0 0 10px` glow effect of their respective color when in an active or hovered state.

## Typography
The typography system uses a mix of technical geometric sans-serifs and precise monospaced faces. 

- **Headlines:** Must always be rendered in All-Caps. Use `Space Grotesk` for its aggressive, wide stance.
- **Body:** `JetBrains Mono` provides superior readability for dense productivity data while maintaining the "code" aesthetic.
- **Labels:** Small metadata and status tags use `Space Mono` with increased letter-spacing to mimic hardware markings.

**Styling Note:** For primary headlines, apply a subtle `0.5px` text-shadow in Cyan to simulate screen phosphor bleed.

## Layout & Spacing
The layout relies on a rigid 4px baseline grid, reflecting the precision of a terminal interface. 

- **Grid:** A 12-column fluid grid for desktop, collapsing to a single column on mobile. 
- **The "Scanline" Overlay:** A global fixed-position overlay using a repeating linear gradient of `transparent` and `rgba(0, 240, 255, 0.03)` every 4px should be applied to the entire viewport.
- **Background Grid:** A subtle background pattern of dark grey lines (`#1A1A24`) should be visible at 32px intervals to provide a sense of scale.

## Elevation & Depth
Depth is not created through shadows, but through **transparency and luminosity**.

- **Z-Index 0:** The dark grid background.
- **Z-Index 1 (Surfaces):** Translucent glass panels (`rgba(18, 18, 26, 0.6)`) with a `12px` backdrop-blur. Each panel features a `1px` solid border of Cyan at `30%` opacity.
- **Z-Index 2 (Active/Modal):** Panels with increased border opacity (`60%`) and a faint outer glow (`box-shadow: 0 0 15px rgba(0, 240, 255, 0.15)`).
- **Floating Elements:** Tooltips and floating action buttons should have a "wireframe" feel, utilizing only borders and no fill where possible.

## Shapes
This design system uses a "Soft Tech" approach. While the grid is rigid, the corners are slightly filed down to ensure the UI feels modern rather than ancient.

- **Default Corner Radius:** 6px.
- **Hard Edges:** 0px for dividers and progress bar containers.
- **Interactive States:** On hover, elements may "expand" their borders slightly or increase their glow intensity, rather than changing shape.

## Components
- **Buttons:** Wireframe style. `1px` Cyan border, no background. On hover: Fill with `rgba(0, 240, 255, 0.1)` and add a `0 0 10px` cyan glow. Text is always All-Caps.
- **Input Fields:** Bottom-border only or a 4-sided wireframe with "corner brackets." The cursor should be a solid Cyan block that pulses.
- **Cards:** Glassmorphic panels. Headers of cards should be separated by a `1px` horizontal line and include a small "Data ID" label in the top-right.
- **Chips/Badges:** Small rectangular boxes with a solid background of the status color (Green/Magenta/Yellow) and black text.
- **Pulsing Indicators:** Status icons (e.g., "Live" or "Syncing") should use a keyframe animation that scales a soft glow ring from `0%` to `150%` size with `0` opacity.
- **Lists:** Rows separated by low-opacity Cyan lines. Hovering over a list item should trigger a "scan" effect—a light horizontal bar that passes quickly from top to bottom.