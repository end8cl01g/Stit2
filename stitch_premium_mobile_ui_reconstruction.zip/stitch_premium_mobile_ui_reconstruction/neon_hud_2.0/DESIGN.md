---
name: Neon HUD 2.0
colors:
  surface: '#131317'
  surface-dim: '#131317'
  surface-bright: '#39393d'
  surface-container-lowest: '#0e0e12'
  surface-container-low: '#1b1b1f'
  surface-container: '#1f1f23'
  surface-container-high: '#2a292e'
  surface-container-highest: '#353439'
  on-surface: '#e5e1e7'
  on-surface-variant: '#b9caca'
  inverse-surface: '#e5e1e7'
  inverse-on-surface: '#303034'
  outline: '#849494'
  outline-variant: '#3a4a4a'
  surface-tint: '#00dce3'
  primary: '#efffff'
  on-primary: '#003739'
  primary-container: '#00f7ff'
  on-primary-container: '#006d71'
  inverse-primary: '#00696d'
  secondary: '#fface6'
  on-secondary: '#5e0052'
  secondary-container: '#ff27e1'
  on-secondary-container: '#520048'
  tertiary: '#f7ffe4'
  on-tertiary: '#1f3700'
  tertiary-container: '#9df700'
  on-tertiary-container: '#436d00'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#54f8ff'
  primary-fixed-dim: '#00dce3'
  on-primary-fixed: '#002021'
  on-primary-fixed-variant: '#004f52'
  secondary-fixed: '#ffd7f0'
  secondary-fixed-dim: '#fface6'
  on-secondary-fixed: '#3a0032'
  on-secondary-fixed-variant: '#850074'
  tertiary-fixed: '#9ffb00'
  tertiary-fixed-dim: '#8bdc00'
  on-tertiary-fixed: '#102000'
  on-tertiary-fixed-variant: '#2f4f00'
  background: '#131317'
  on-background: '#e5e1e7'
  surface-variant: '#353439'
  surface-panel: '#12121A'
  grid-line: '#1A1A24'
  text-primary: '#e4e1e9'
  glow-cyan: rgba(0, 247, 255, 0.4)
  scanline-tint: rgba(0, 247, 255, 0.03)
typography:
  display-lg:
    fontFamily: Space Grotesk
    fontSize: 42px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Space Grotesk
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 34px
    letterSpacing: 0.05em
  headline-lg-mobile:
    fontFamily: Space Grotesk
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 30px
  data-huge:
    fontFamily: JetBrains Mono
    fontSize: 48px
    fontWeight: '800'
    lineHeight: 48px
    letterSpacing: -0.05em
  body-md:
    fontFamily: JetBrains Mono
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-caps:
    fontFamily: JetBrains Mono
    fontSize: 10px
    fontWeight: '700'
    lineHeight: 12px
    letterSpacing: 0.15em
  hud-micro:
    fontFamily: JetBrains Mono
    fontSize: 9px
    fontWeight: '500'
    lineHeight: 10px
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  unit: 4px
  gutter: 16px
  margin-mobile: 20px
  panel-padding: 24px
  grid-size: 32px
---

## Brand & Style
The design system embodies the "Neon HUD 2.0" aesthetic—a high-performance, elite-productivity interface designed for the "Neural Network" era. The brand personality is **Technical, Urgent, and Gamified**, transforming a standard mobile utility into a high-fidelity cyberdeck.

The style is a fusion of **Cyberpunk Minimalism** and **Glassmorphism**. It utilizes deep space blacks to maintain high contrast, while layered "light-leak" gradients and frosted glass panels provide a sense of luxury and depth. The emotional response should be one of "flow state" and "digital mastery," where every interaction feels like a high-stakes command within a high-performance engine.

**Key Visual Principles:**
- **Hyper-Vibrancy:** Accents must feel like they are emitting light, not just reflecting it.
- **Glass-on-Steel:** Use high-opacity backdrop blurs (12px-20px) to simulate premium hardware interfaces.
- **Precision Engineering:** Thin, 1px high-contrast borders and monospaced data points communicate accuracy and system-level control.

## Colors
The palette is built on a "Vantablack" foundation using `#050508` to maximize the luminance of the neon accents.

- **Primary (Electric Cyan):** The core interactive color. Used for primary actions, focus states, and the most critical HUD information.
- **Secondary (Hot Magenta):** Used for decorative accents, warnings, and high-energy secondary actions.
- **Tertiary (Toxic Lime):** Specifically reserved for "System Clear," "Task Complete," and positive performance metrics.
- **Surface Strategy:** Backgrounds utilize deep charcoal layers (`#12121A`) with varying opacities to create a sense of stacked glass.
- **Glow Effects:** Every brand color has a corresponding "Glow" token used for box-shadows and text-shadows to simulate light emission.

## Typography
The typography strategy separates **Display/Emotional** text from **Functional/Data** text.

- **Space Grotesk** is used for headlines and branding. It should always be used with tight letter-spacing for large displays and wider spacing for section headers to evoke a modernist HUD feel.
- **JetBrains Mono** handles all body content, data, and system feedback. This reinforces the "Neural Network" theme, suggesting that the user is interacting directly with the system's core logic.
- **Transformations:** All `label-caps` and `headline` levels must be rendered in `uppercase` to maintain the technical aesthetic.
- **Styling:** Key data points (like timers or percentages) should use `data-huge` with a subtle `text-shadow` in the primary color.

## Layout & Spacing
The layout uses a **Fluid Grid** model with a rigid underlying 4px rhythm.

- **Background Grid:** A permanent background pattern of 32px x 32px squares (using `grid-line` color) provides a visual anchor for all elements.
- **Mobile Layout:** On mobile, components should stretch to the `margin-mobile` width. 
- **Panels:** Content is grouped into "Glass Panels" with `panel-padding`. These panels should have a 1px border and a subtle internal glow.
- **Vertical Rhythm:** Space between major sections should be 24px-32px to allow the "Deep Space" background to breathe, emphasizing the floating HUD effect.

## Elevation & Depth
Elevation is not conveyed through traditional shadows, but through **Luminance, Blur, and Layering**.

- **Level 0 (Base):** Deep space black (`#050508`) with the 32px grid and 3% opacity scanline overlay.
- **Level 1 (Panels):** Semi-transparent `#12121A` (80% opacity) with a `blur(12px)` and a 1px border of `rgba(0, 247, 255, 0.2)`.
- **Level 2 (Active/Focus):** Panels or buttons that are active gain a `box-shadow` glow of 15px-20px using the `glow-cyan` token.
- **Overlay Level:** Modals and high-priority alerts use a 90% opaque background and increased blur (20px), often framed by a full-intensity `primary` or `secondary` 2px border.

## Shapes
The shape language is **Technical and Crisp**. 

- **Radii:** A consistent `4px` (`Soft`) radius is used for all panels, buttons, and input fields. This ensures the UI feels modern but retains a "sharp" military-grade precision.
- **Borders:** Use thin 1px lines for standard state and 2px lines for focus or active states. 
- **Accents:** Use "clipped corner" effects (via CSS clip-path) on large buttons or hero panels to further emphasize the futuristic HUD aesthetic.

## Components
- **Massive Buttons:** Primary actions use a 2px solid `primary` border, uppercase `Space Grotesk` text, and a constant subtle outer glow. On press, they scale to `0.98` and the glow intensifies.
- **Neon Inputs:** Fields are transparent with a 1px bottom-border. On focus, the border transitions to the `primary` color and the entire field gains a subtle `primary` background tint (5% opacity).
- **Glass Chips:** Small status indicators with a `blur(4px)` background, high-contrast text, and a `secondary` or `tertiary` left-side 2px "status bar."
- **Neural Lists:** List items should be separated by the `grid-line` color. Each item features a monospaced "Index ID" (e.g., [01], [02]) in the `hud-micro` style.
- **Progress Bars:** Thin, 4px tall bars. The filled portion should be a gradient from `primary` to `secondary`, with a "leading light" (a small 10px glow) at the head of the progress.
- **Scanline Overlay:** A global fixed overlay with a repeating linear gradient of transparent and `scanline-tint` to simulate a high-fidelity CRT monitor.