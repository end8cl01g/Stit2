---
name: 90Days
colors:
  surface: '#10131a'
  surface-dim: '#10131a'
  surface-bright: '#363941'
  surface-container-lowest: '#0b0e15'
  surface-container-low: '#191b23'
  surface-container: '#1d2027'
  surface-container-high: '#272a31'
  surface-container-highest: '#32353c'
  on-surface: '#e1e2ec'
  on-surface-variant: '#c2c6d6'
  inverse-surface: '#e1e2ec'
  inverse-on-surface: '#2e3038'
  outline: '#8c909f'
  outline-variant: '#424754'
  surface-tint: '#adc6ff'
  primary: '#adc6ff'
  on-primary: '#002e6a'
  primary-container: '#4d8eff'
  on-primary-container: '#00285d'
  inverse-primary: '#005ac2'
  secondary: '#b9c8de'
  on-secondary: '#233143'
  secondary-container: '#39485a'
  on-secondary-container: '#a7b6cc'
  tertiary: '#ffb786'
  on-tertiary: '#502400'
  tertiary-container: '#df7412'
  on-tertiary-container: '#461f00'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#d8e2ff'
  primary-fixed-dim: '#adc6ff'
  on-primary-fixed: '#001a42'
  on-primary-fixed-variant: '#004395'
  secondary-fixed: '#d4e4fa'
  secondary-fixed-dim: '#b9c8de'
  on-secondary-fixed: '#0d1c2d'
  on-secondary-fixed-variant: '#39485a'
  tertiary-fixed: '#ffdcc6'
  tertiary-fixed-dim: '#ffb786'
  on-tertiary-fixed: '#311400'
  on-tertiary-fixed-variant: '#723600'
  background: '#10131a'
  on-background: '#e1e2ec'
  surface-variant: '#32353c'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Inter
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
  headline-md:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-lg:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.05em
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  unit: 4px
  touch-target-min: 48px
  margin-mobile: 20px
  gutter: 16px
  stack-sm: 8px
  stack-md: 16px
  stack-lg: 32px
  stack-xl: 64px
---

## Brand & Style

The design system is centered on recovery, resilience, and clarity. It prioritizes a low-stimulation environment to reduce cognitive load and emotional triggers for users in high-stress states. The aesthetic is **Functional Minimalism**—stripping away decorative elements to focus entirely on utility and support.

The emotional response should be one of stability and safety. By utilizing deep dark surfaces and a restricted color palette, the interface recedes into the background, allowing the user's progress and immediate actions to remain the sole focus.

- **Minimalism:** Heavy use of negative space to prevent a sense of "clutter" or overwhelm.
- **Supportive:** Direct, clear language and high-contrast touch targets for accessibility during moments of distress.
- **Non-Triggering:** Absence of high-energy gradients, rapid animations, or aggressive marketing patterns.

## Colors

The color strategy is strictly functional, mapping color to the user's recovery journey and emotional state.

- **Base Surfaces:** The background is an absolute deep black (`#0a0a0a`) to minimize light emission and eye strain. Surface containers use `#1a1a1a` to provide subtle depth without high contrast.
- **Primary & Neutral:** Blues and grays provide a calm, professional tone that feels clinical yet supportive.
- **Progression Logic:** 
    - **Neutral Gray (`#4b5563`):** Used for the initial "Stability" phase (Day 1-29).
    - **Focused Blue (`#2563eb`):** Used for the "Momentum" phase (Day 30-89).
    - **Milestone Gold (`#fbbf24`):** Used exclusively for the "Resilience" phase (90+ Days) to provide a sense of quiet achievement.
- **SOS/Danger:** High-visibility Red (`#ef4444`) is reserved strictly for emergency "Relapse Prevention" or "Help" actions.

## Typography

This design system utilizes **Inter** for its exceptional legibility and neutral character. 

- **Scale:** Font sizes are slightly larger than standard web defaults to ensure clarity during moments of physical or mental fatigue.
- **Hierarchy:** High-weight headers (Semi-bold/Bold) are used to anchor the page, while body text maintains a generous line height (1.5x+) for effortless reading.
- **Letter Spacing:** Headlines use slight negative tracking for a more grounded, stable appearance. Labels use increased tracking for better scanability on dark backgrounds.

## Layout & Spacing

The layout philosophy is **Task-Focused Fluidity**. Every screen should be designed to be understood and acted upon within 3 seconds.

- **Grid:** A simple 4-column fluid grid for mobile. Elements should prioritize full-width "stack" layouts to avoid complex eye movements across the horizontal axis.
- **Touch Targets:** A strict minimum of 48x48px for all interactive elements to accommodate users who may be experiencing tremors or reduced motor control.
- **Vertical Rhythm:** Generous vertical spacing (32px+) between distinct sections to prevent information bleed.
- **Padding:** Content containers must have a minimum of 16px internal padding to maintain a "breathable" feel.

## Elevation & Depth

Depth is conveyed through **Tonal Layering** rather than traditional shadows. In a deep dark mode, shadows are often invisible or create unnecessary visual noise.

- **Layer 0 (Background):** `#0a0a0a` - The base of the application.
- **Layer 1 (Cards/Containers):** `#1a1a1a` - Used for grouping content. 
- **Layer 2 (Modals/Overlays):** `#262626` - Used for temporary focus states.
- **Outlines:** Use a low-contrast border (`#ffffff` at 10% opacity) instead of shadows to define container boundaries. This maintains a flat, grounded feel.

## Shapes

The shape language is **Soft and Precise**. 

- **Standard Radius:** 4px (Soft) for buttons and inputs. This provides a clean, professional look that isn't as aggressive as sharp corners, but avoids the "playfulness" of highly rounded or pill-shaped elements.
- **Large Radius:** 8px for cards and major surface containers to distinguish them from smaller UI components.

## Components

### Buttons
- **Primary:** Solid background (Color depends on Day count). Text is high-contrast white or black depending on the background brightness.
- **Secondary:** Outlined with 1px border, transparent background.
- **SOS Button:** Fixed position (bottom right or top right), Solid Red (`#ef4444`), always accessible.

### Cards
- No shadows. Use `#1a1a1a` background with a subtle 1px border of `#262626`.
- Internal padding is strictly 20px.

### Inputs
- Full-width fields only. 
- 48px height. 
- Deep background (`#000000`) with a subtle 1px border. 
- Focus state is indicated by a Primary Blue border; no "glow" or outer shadows.

### Progress Indicators
- **The "Day Counter":** Large Display-LG typography. The color of the number changes based on the 30/90 day logic.
- **Linear Progress Bars:** 8px height, rounded. The track is `#262626`, the filler is the status-specific color.

### Checklists / Lists
- Designed for "Daily Check-ins."
- Large 24px tap targets for checkboxes.
- High-contrast text for active items; 40% opacity for completed items to reduce visual weight.