/**
 * DayForge — 高密度結構化日程
 * Google Apps Script backend (T-1 layer)
 *
 * Sheets used (auto-created by setup()):
 *   Schedule  A:date  B:timeSlot  C:activity  D:category  E:completed  F:note  G:id  H:durationMin
 *   Templates A:id    B:name      C:category  D:durationMin  E:icon
 *   Review    A:date  B:rate      C:reflection  D:updatedAt
 *   Settings  A:key   B:value
 */

// ============================================================
// CONFIG
// ============================================================

var CONFIG = {
  TZ: 'Asia/Tokyo',          // 改成你的時區 (Asia/Taipei / Asia/Tokyo)
  SHEET_SCHEDULE: 'Schedule',
  SHEET_TEMPLATES: 'Templates',
  SHEET_REVIEW: 'Review',
  SHEET_SETTINGS: 'Settings',
  PROP_SHEET_ID: 'DAYFORGE_SHEET_ID',
  HISTORY_DAYS: 30
};

var SCHEDULE_HEADERS = ['date', 'timeSlot', 'activity', 'category', 'completed', 'note', 'id', 'durationMin'];

var DEFAULT_TEMPLATES = [
  ['tpl_run',   '晨跑 5K',      '運動', 30,  'directions_run'],
  ['tpl_med',   '冥想 15 分鐘',  '休息', 15,  'self_improvement'],
  ['tpl_deep',  '深度工作 2hr',  '目標', 120, 'psychology'],
  ['tpl_call',  '社交電話',      '社交', 45,  'call'],
  ['tpl_cook',  '做飯',         '生活', 60,  'restaurant'],
  ['tpl_walk',  '休息散步',      '休息', 20,  'park'],
  ['tpl_study', '閱讀 / 學習',   '學習', 60,  'menu_book'],
  ['tpl_hiit',  'HIIT 訓練',    '運動', 30,  'fitness_center']
];

var DEFAULT_SETTINGS = {
  startHour: '6',
  endHour: '24',
  granularity: '30',
  theme: 'dark'
};

// ============================================================
// WEB APP ENTRY
// ============================================================

/**
 * Apps Script only permits these four meta tags via addMetaTag():
 *   viewport · apple-mobile-web-app-capable · mobile-web-app-capable · google-site-verification
 * Anything else (theme-color, description, …) throws
 * "The meta tag you specified is not allowed in this context."
 * Meta tags written directly into the HTML file are silently ignored,
 * so there is no workaround — theme-color simply isn't available on GAS.
 */
function doGet(e) {
  return HtmlService.createTemplateFromFile('Index')
    .evaluate()
    .setTitle('DayForge — 高密度日程')
    .addMetaTag('viewport', 'width=device-width, initial-scale=1, maximum-scale=1, viewport-fit=cover')
    .addMetaTag('apple-mobile-web-app-capable', 'yes')
    .addMetaTag('mobile-web-app-capable', 'yes')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

/** Inline an HTML partial from a template: <?!= include('Stylesheet') ?> */
function include(filename) {
  return HtmlService.createHtmlOutputFromFile(filename).getContent();
}

// ============================================================
// SPREADSHEET PLUMBING
// ============================================================

/**
 * Run this ONCE from the editor. Creates the spreadsheet + all tabs,
 * seeds templates and settings, and stores the ID in Script Properties.
 * No hardcoded YOUR_SHEET_ID needed.
 */
function setup() {
  var props = PropertiesService.getScriptProperties();
  var id = props.getProperty(CONFIG.PROP_SHEET_ID);
  var ss;

  if (id) {
    try { ss = SpreadsheetApp.openById(id); } catch (err) { ss = null; }
  }
  if (!ss) {
    ss = SpreadsheetApp.create('DayForge Data');
    props.setProperty(CONFIG.PROP_SHEET_ID, ss.getId());
  }

  ensureSheet_(ss, CONFIG.SHEET_SCHEDULE, SCHEDULE_HEADERS);
  var tpl = ensureSheet_(ss, CONFIG.SHEET_TEMPLATES, ['id', 'name', 'category', 'durationMin', 'icon']);
  ensureSheet_(ss, CONFIG.SHEET_REVIEW, ['date', 'rate', 'reflection', 'updatedAt']);
  var set = ensureSheet_(ss, CONFIG.SHEET_SETTINGS, ['key', 'value']);

  if (tpl.getLastRow() < 2) {
    tpl.getRange(2, 1, DEFAULT_TEMPLATES.length, 5).setValues(DEFAULT_TEMPLATES);
  }
  if (set.getLastRow() < 2) {
    var rows = Object.keys(DEFAULT_SETTINGS).map(function (k) { return [k, DEFAULT_SETTINGS[k]]; });
    set.getRange(2, 1, rows.length, 2).setValues(rows);
  }

  // Remove the default empty "Sheet1" if it snuck in
  var junk = ss.getSheetByName('Sheet1');
  if (junk && ss.getSheets().length > 1 && junk.getLastRow() === 0) ss.deleteSheet(junk);

  var url = ss.getUrl();
  Logger.log('DayForge ready → ' + url);
  return url;
}

function ss_() {
  var id = PropertiesService.getScriptProperties().getProperty(CONFIG.PROP_SHEET_ID);
  if (!id) {
    // Container-bound fallback
    var active = SpreadsheetApp.getActiveSpreadsheet();
    if (active) return active;
    throw new Error('尚未初始化：請先在編輯器執行一次 setup()。');
  }
  return SpreadsheetApp.openById(id);
}

function sheet_(name) {
  var sh = ss_().getSheetByName(name);
  if (!sh) throw new Error('找不到工作表：' + name + '（請執行 setup()）');
  return sh;
}

function ensureSheet_(ss, name, headers) {
  var sh = ss.getSheetByName(name);
  if (!sh) sh = ss.insertSheet(name);
  if (sh.getLastRow() === 0) {
    sh.getRange(1, 1, 1, headers.length).setValues([headers])
      .setFontWeight('bold').setBackground('#201f1f').setFontColor('#9adbff');
    sh.setFrozenRows(1);
  }
  return sh;
}

// ============================================================
// HELPERS
// ============================================================

function today_() {
  return Utilities.formatDate(new Date(), CONFIG.TZ, 'yyyy-MM-dd');
}

/** instanceof is unreliable across execution contexts — duck-type instead. */
function isDate_(v) {
  return Object.prototype.toString.call(v) === '[object Date]' && !isNaN(v.getTime());
}

/** Normalise anything Sheets might hand back into a real date string. */
function dateKey_(v) {
  if (isDate_(v)) return Utilities.formatDate(v, CONFIG.TZ, 'yyyy-MM-dd');
  return String(v || '').trim().slice(0, 10);
}

/** Sheets may return boolean, 'TRUE', 'true' or 1 — normalise all of them. */
function toBool_(v) {
  if (v === true) return true;
  if (v === false || v === '' || v == null) return false;
  var s = String(v).trim().toLowerCase();
  return s === 'true' || s === '1' || s === 'yes';
}

/** Sheets can return a Date object for an HH:mm cell — normalise to 'HH:mm'. */
function slotKey_(v) {
  if (isDate_(v)) {
    // A bare time cell is stored on the 1899-12-30 epoch; read it directly
    // instead of via the script timezone, which would shift the hour.
    return ('0' + v.getHours()).slice(-2) + ':' + ('0' + v.getMinutes()).slice(-2);
  }
  var s = String(v || '').trim();
  var m = s.match(/^(\d{1,2}):(\d{2})/);
  return m ? ('0' + m[1]).slice(-2) + ':' + m[2] : s;
}

function uid_() {
  return 'a' + Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
}

/**
 * Clamp a duration so it is positive and cannot run past the end of the day.
 * Custom end times mean durationMin is now arbitrary, not one of 4 presets.
 */
function cleanDuration_(durationMin, timeSlot) {
  var d = Math.round(Number(durationMin));
  if (!isFinite(d) || d <= 0) d = 30;
  var slot = slotKey_(timeSlot);
  var m = slot.match(/^(\d{2}):(\d{2})$/);
  if (m) {
    var startMin = parseInt(m[1], 10) * 60 + parseInt(m[2], 10);
    var room = 24 * 60 - startMin;
    if (room > 0 && d > room) d = room;
  }
  return d;
}

function withLock_(fn) {
  var lock = LockService.getScriptLock();
  lock.waitLock(20000);
  try { return fn(); } finally { lock.releaseLock(); }
}

function rowToRecord_(r) {
  return {
    date: dateKey_(r[0]),
    timeSlot: slotKey_(r[1]),
    activity: String(r[2] || ''),
    category: String(r[3] || ''),
    completed: toBool_(r[4]),
    note: String(r[5] || ''),
    id: String(r[6] || ''),
    durationMin: Number(r[7]) || 30
  };
}

// ============================================================
// READ
// ============================================================

/** Everything the client needs on first paint, in ONE round trip. */
function bootstrap() {
  var d = today_();
  return {
    today: d,
    schedule: getSchedule(d),
    templates: getTemplates(),
    settings: getSettings(),
    review: getReview(d),
    serverTime: Utilities.formatDate(new Date(), CONFIG.TZ, 'HH:mm'),
    tz: CONFIG.TZ
  };
}

function getSchedule(date) {
  date = date || today_();
  var sh = sheet_(CONFIG.SHEET_SCHEDULE);
  if (sh.getLastRow() < 2) return [];
  var data = sh.getRange(2, 1, sh.getLastRow() - 1, SCHEDULE_HEADERS.length).getValues();
  var out = [];
  for (var i = 0; i < data.length; i++) {
    if (!data[i][0] && !data[i][2]) continue;
    if (dateKey_(data[i][0]) === date) out.push(rowToRecord_(data[i]));
  }
  out.sort(function (a, b) { return a.timeSlot < b.timeSlot ? -1 : a.timeSlot > b.timeSlot ? 1 : 0; });
  return out;
}

function getTemplates() {
  var sh = sheet_(CONFIG.SHEET_TEMPLATES);
  if (sh.getLastRow() < 2) return [];
  return sh.getRange(2, 1, sh.getLastRow() - 1, 5).getValues()
    .filter(function (r) { return r[1]; })
    .map(function (r) {
      return {
        id: String(r[0]), name: String(r[1]), category: String(r[2]),
        durationMin: Number(r[3]) || 30, icon: String(r[4] || 'bolt')
      };
    });
}

function getSettings() {
  var sh = sheet_(CONFIG.SHEET_SETTINGS);
  var s = {};
  Object.keys(DEFAULT_SETTINGS).forEach(function (k) { s[k] = DEFAULT_SETTINGS[k]; });
  if (sh.getLastRow() >= 2) {
    sh.getRange(2, 1, sh.getLastRow() - 1, 2).getValues().forEach(function (r) {
      if (r[0]) s[String(r[0])] = String(r[1]);
    });
  }
  return s;
}

function getReview(date) {
  date = date || today_();
  var sh = sheet_(CONFIG.SHEET_REVIEW);
  if (sh.getLastRow() < 2) return { date: date, rate: 0, reflection: '' };
  var data = sh.getRange(2, 1, sh.getLastRow() - 1, 4).getValues();
  for (var i = 0; i < data.length; i++) {
    if (dateKey_(data[i][0]) === date) {
      return { date: date, rate: Number(data[i][1]) || 0, reflection: String(data[i][2] || '') };
    }
  }
  return { date: date, rate: 0, reflection: '' };
}

/** Completion rate + minutes-per-category, for Screen 4. */
function getDayStats(date) {
  date = date || today_();
  var rows = getSchedule(date);
  var done = 0, totalMin = 0, byCat = {};
  rows.forEach(function (r) {
    if (r.completed) done++;
    totalMin += r.durationMin;
    byCat[r.category] = (byCat[r.category] || 0) + r.durationMin;
  });
  var cats = Object.keys(byCat).map(function (k) {
    return { category: k, minutes: byCat[k], share: totalMin ? Math.round(byCat[k] / totalMin * 100) : 0 };
  }).sort(function (a, b) { return b.minutes - a.minutes; });

  return {
    date: date,
    total: rows.length,
    completed: done,
    rate: rows.length ? Math.round(done / rows.length * 100) : 0,
    totalMinutes: totalMin,
    categories: cats
  };
}

/** Kept for API compatibility with the original plan. */
function getTodaySchedule() { return getSchedule(today_()); }
function getCompletionRate() { return getDayStats(today_()).rate; }

/** Last N days of completion rates, for the Review sparkline. */
function getHistory(days) {
  days = days || CONFIG.HISTORY_DAYS;
  var sh = sheet_(CONFIG.SHEET_SCHEDULE);
  if (sh.getLastRow() < 2) return [];
  var data = sh.getRange(2, 1, sh.getLastRow() - 1, SCHEDULE_HEADERS.length).getValues();

  var cutoff = new Date();
  cutoff.setDate(cutoff.getDate() - days);
  var cutoffKey = Utilities.formatDate(cutoff, CONFIG.TZ, 'yyyy-MM-dd');

  var agg = {};
  data.forEach(function (r) {
    var d = dateKey_(r[0]);
    if (!d || d < cutoffKey) return;
    if (!agg[d]) agg[d] = { date: d, total: 0, completed: 0 };
    agg[d].total++;
    if (toBool_(r[4])) agg[d].completed++;
  });

  return Object.keys(agg).sort().map(function (d) {
    var a = agg[d];
    a.rate = a.total ? Math.round(a.completed / a.total * 100) : 0;
    return a;
  });
}

// ============================================================
// WRITE
// ============================================================

function addActivity(record) {
  if (!record || !record.activity) throw new Error('活動名稱不可為空');
  return withLock_(function () {
    var sh = sheet_(CONFIG.SHEET_SCHEDULE);
    var id = record.id || uid_();
    sh.appendRow([
      record.date || today_(),
      slotKey_(record.timeSlot),
      String(record.activity).slice(0, 200),
      record.category || '目標',
      false,
      String(record.note || '').slice(0, 500),
      id,
      cleanDuration_(record.durationMin, record.timeSlot)
    ]);
    return { ok: true, id: id, schedule: getSchedule(record.date || today_()) };
  });
}

function updateActivity(record) {
  if (!record || !record.id) throw new Error('缺少 id');
  return withLock_(function () {
    var sh = sheet_(CONFIG.SHEET_SCHEDULE);
    var n = sh.getLastRow() - 1;
    if (n < 1) throw new Error('查無資料');
    var ids = sh.getRange(2, 7, n, 1).getValues();
    for (var i = 0; i < n; i++) {
      if (String(ids[i][0]) === String(record.id)) {
        var row = i + 2;
        var cur = sh.getRange(row, 1, 1, SCHEDULE_HEADERS.length).getValues()[0];
        var newSlot = slotKey_(record.timeSlot || cur[1]);
        sh.getRange(row, 1, 1, SCHEDULE_HEADERS.length).setValues([[
          record.date || dateKey_(cur[0]),
          newSlot,
          record.activity != null ? String(record.activity).slice(0, 200) : cur[2],
          record.category || cur[3],
          record.completed != null ? !!record.completed : toBool_(cur[4]),
          record.note != null ? String(record.note).slice(0, 500) : cur[5],
          record.id,
          cleanDuration_(record.durationMin || cur[7], newSlot)
        ]]);
        return { ok: true, schedule: getSchedule(record.date || dateKey_(cur[0])) };
      }
    }
    throw new Error('查無此活動');
  });
}

function deleteActivity(id) {
  if (!id) throw new Error('缺少 id');
  return withLock_(function () {
    var sh = sheet_(CONFIG.SHEET_SCHEDULE);
    var n = sh.getLastRow() - 1;
    if (n < 1) return { ok: false };
    var ids = sh.getRange(2, 7, n, 1).getValues();
    for (var i = 0; i < n; i++) {
      if (String(ids[i][0]) === String(id)) {
        var d = dateKey_(sh.getRange(i + 2, 1).getValue());
        sh.deleteRow(i + 2);
        return { ok: true, schedule: getSchedule(d) };
      }
    }
    return { ok: false };
  });
}

/** Toggle by id (preferred) — returns the new boolean state. */
function toggleActivity(id) {
  if (!id) throw new Error('缺少 id');
  return withLock_(function () {
    var sh = sheet_(CONFIG.SHEET_SCHEDULE);
    var n = sh.getLastRow() - 1;
    if (n < 1) return null;
    var ids = sh.getRange(2, 7, n, 1).getValues();
    for (var i = 0; i < n; i++) {
      if (String(ids[i][0]) === String(id)) {
        var cell = sh.getRange(i + 2, 5);
        var next = !toBool_(cell.getValue());
        cell.setValue(next);
        return { ok: true, id: id, completed: next };
      }
    }
    return null;
  });
}

/** Legacy signature from the original plan (date + timeSlot). */
function toggleComplete(date, timeSlot) {
  return withLock_(function () {
    var sh = sheet_(CONFIG.SHEET_SCHEDULE);
    var n = sh.getLastRow() - 1;
    if (n < 1) return null;
    var data = sh.getRange(2, 1, n, SCHEDULE_HEADERS.length).getValues();
    var slot = slotKey_(timeSlot);
    for (var i = 0; i < n; i++) {
      if (dateKey_(data[i][0]) === date && slotKey_(data[i][1]) === slot) {
        var next = !toBool_(data[i][4]);
        sh.getRange(i + 2, 5).setValue(next);
        return next;
      }
    }
    return null;
  });
}

/** Apply a whole template into a slot. */
function applyTemplate(templateId, date, timeSlot) {
  var t = getTemplates().filter(function (x) { return x.id === templateId; })[0];
  if (!t) throw new Error('查無此模板');
  return addActivity({
    date: date || today_(),
    timeSlot: timeSlot,
    activity: t.name,
    category: t.category,
    durationMin: t.durationMin,
    note: ''
  });
}

function saveTemplate(t) {
  if (!t || !t.name) throw new Error('模板名稱不可為空');
  return withLock_(function () {
    sheet_(CONFIG.SHEET_TEMPLATES).appendRow([
      t.id || uid_(), String(t.name).slice(0, 100),
      t.category || '目標', Number(t.durationMin) || 30, t.icon || 'bolt'
    ]);
    return getTemplates();
  });
}

function deleteTemplate(id) {
  return withLock_(function () {
    var sh = sheet_(CONFIG.SHEET_TEMPLATES);
    var n = sh.getLastRow() - 1;
    if (n < 1) return getTemplates();
    var ids = sh.getRange(2, 1, n, 1).getValues();
    for (var i = 0; i < n; i++) {
      if (String(ids[i][0]) === String(id)) { sh.deleteRow(i + 2); break; }
    }
    return getTemplates();
  });
}

function saveReview(date, reflection) {
  date = date || today_();
  var rate = getDayStats(date).rate;
  return withLock_(function () {
    var sh = sheet_(CONFIG.SHEET_REVIEW);
    var stamp = Utilities.formatDate(new Date(), CONFIG.TZ, 'yyyy-MM-dd HH:mm');
    var n = sh.getLastRow() - 1;
    if (n > 0) {
      var dates = sh.getRange(2, 1, n, 1).getValues();
      for (var i = 0; i < n; i++) {
        if (dateKey_(dates[i][0]) === date) {
          sh.getRange(i + 2, 1, 1, 4).setValues([[date, rate, String(reflection || ''), stamp]]);
          return { ok: true, rate: rate };
        }
      }
    }
    sh.appendRow([date, rate, String(reflection || ''), stamp]);
    return { ok: true, rate: rate };
  });
}

function saveSettings(patch) {
  return withLock_(function () {
    var sh = sheet_(CONFIG.SHEET_SETTINGS);
    var n = Math.max(sh.getLastRow() - 1, 0);
    var existing = n ? sh.getRange(2, 1, n, 2).getValues() : [];
    var index = {};
    existing.forEach(function (r, i) { index[String(r[0])] = i + 2; });

    Object.keys(patch || {}).forEach(function (k) {
      if (index[k]) sh.getRange(index[k], 2).setValue(String(patch[k]));
      else sh.appendRow([k, String(patch[k])]);
    });
    return getSettings();
  });
}

function clearDay(date) {
  date = date || today_();
  return withLock_(function () {
    var sh = sheet_(CONFIG.SHEET_SCHEDULE);
    var n = sh.getLastRow() - 1;
    if (n < 1) return { ok: true, schedule: [] };
    var dates = sh.getRange(2, 1, n, 1).getValues();
    for (var i = n - 1; i >= 0; i--) {           // delete bottom-up
      if (dateKey_(dates[i][0]) === date) sh.deleteRow(i + 2);
    }
    return { ok: true, schedule: [] };
  });
}
