---
name: LumiBudget
colors:
  surface: '#0e141a'
  surface-dim: '#0e141a'
  surface-bright: '#333a40'
  surface-container-lowest: '#080f14'
  surface-container-low: '#161c22'
  surface-container: '#1a2026'
  surface-container-high: '#242b31'
  surface-container-highest: '#2f353c'
  on-surface: '#dde3eb'
  on-surface-variant: '#bbcac6'
  inverse-surface: '#dde3eb'
  inverse-on-surface: '#2b3137'
  outline: '#859490'
  outline-variant: '#3c4947'
  surface-tint: '#4fdbc8'
  primary: '#4fdbc8'
  on-primary: '#003731'
  primary-container: '#14b8a6'
  on-primary-container: '#00423b'
  inverse-primary: '#006b5f'
  secondary: '#c3c0ff'
  on-secondary: '#1d00a5'
  secondary-container: '#3626ce'
  on-secondary-container: '#b3b1ff'
  tertiary: '#ffb95f'
  on-tertiary: '#472a00'
  tertiary-container: '#e49200'
  on-tertiary-container: '#543300'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#71f8e4'
  primary-fixed-dim: '#4fdbc8'
  on-primary-fixed: '#00201c'
  on-primary-fixed-variant: '#005048'
  secondary-fixed: '#e2dfff'
  secondary-fixed-dim: '#c3c0ff'
  on-secondary-fixed: '#0f0069'
  on-secondary-fixed-variant: '#3323cc'
  tertiary-fixed: '#ffddb8'
  tertiary-fixed-dim: '#ffb95f'
  on-tertiary-fixed: '#2a1700'
  on-tertiary-fixed-variant: '#653e00'
  background: '#0e141a'
  on-background: '#dde3eb'
  surface-variant: '#2f353c'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 40px
    fontWeight: '700'
    lineHeight: '1.2'
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Noto Sans TC
    fontSize: 24px
    fontWeight: '700'
    lineHeight: '1.4'
  body-lg:
    fontFamily: Noto Sans TC
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Noto Sans TC
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.5'
  data-mono:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '500'
    lineHeight: '1.0'
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Noto Sans TC
    fontSize: 13px
    fontWeight: '500'
    lineHeight: '1.2'
    letterSpacing: 0.05em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 8px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 32px
  container-max: 1200px
---

## Brand & Style

The design system is engineered for a high-end fintech experience, blending the precision of modern banking with the ethereal aesthetics of **Glassmorphism**. The interface aims to evoke feelings of security, prosperity, and clarity. 

By utilizing deep oceanic gradients layered with translucent frosted surfaces, the UI creates a sense of physical depth. Subtle glows and gold accents highlight financial growth and "premium" status. The aesthetic is sophisticated yet functional, ensuring that complex financial data remains legible through a "structured-transparency" lens.

## Colors

The palette is anchored in a dark-mode-first approach to reduce eye strain and emphasize the glass effects.

- **Background:** A deep navy-to-midnight gradient (#071126 to #121A3A) serves as the canvas.
- **Primary (Action/Teal):** Used for primary calls to action and navigational highlights.
- **Secondary (Data/Indigo):** Used for secondary interactions and trend indicators.
- **Semantic Logic:**
    - **Income (Success):** Jade Green is used exclusively for positive cash flow.
    - **Expense (Danger):** Coral Red signals outflows and budget alerts.
    - **Reserved (Warning):** Amber Gold is used for savings goals or pending items.
- **Glass Surface:** White at 5-10% opacity with a background blur (12px - 20px) creates the frosted glass effect.

## Typography

This design system uses a dual-font strategy to balance cultural context with numerical precision.

- **Primary Font:** **Noto Sans TC** provides a clean, modern aesthetic for Traditional Chinese characters (HK/TW), ensuring high legibility in financial contexts.
- **Secondary Font:** **Inter** is reserved for all numerical data, currencies (HKD), and timestamps. Its high x-height and tabular figures prevent shifting when numbers change.
- **Currency Display:** Always prefix amounts with "HK$" using the `data-mono` style.
- **Date/Time:** Use the format `YYYY-MM-DD` and `週一` through `週日`.

## Layout & Spacing

This design system employs an **8px linear spacing scale**. All margins, paddings, and component heights must be multiples of 8.

- **Grid:** A 12-column fluid grid is used for desktop (breakpoint: 1024px), transitioning to a single-column layout for mobile.
- **Margins:** Desktop views use 40px external margins; mobile views use 16px.
- **Gaps:** Standard card gap is 24px on desktop and 16px on mobile.
- **Reflow:** On mobile, side-by-side charts reflow to a vertical stack. Data tables should allow horizontal scrolling on small screens to maintain column integrity.

## Elevation & Depth

Hierarchy is established through **Z-axis transparency** rather than heavy shadows.

- **Level 0 (Base):** The dark navy gradient background.
- **Level 1 (Cards):** Semi-transparent white (#FFFFFF at 0.05 opacity) with a 20px `backdrop-filter: blur()`. A subtle 1px border (#FFFFFF at 0.1 opacity) defines the edges.
- **Level 2 (Modals/Popovers):** Higher opacity (#FFFFFF at 0.12 opacity) with a soft outer glow in the primary color (Teal/Indigo) at 15% opacity to indicate focus.
- **Shadows:** Use a single, very soft "ambient" shadow: `0 8px 32px 0 rgba(0, 0, 0, 0.3)`. Avoid harsh, dark shadows that break the glass illusion.

## Shapes

The shape language is generous and approachable, using large radii to soften the "cold" tech feel of fintech apps.

- **Containers & Cards:** Use a border radius between **18px and 24px** (Standard: 20px).
- **Interactive Elements:** Inputs and smaller modules use **12px to 14px**.
- **Buttons:** Primary buttons use a **pill-shape** (fully rounded) to maximize clickability and contrast against the rectangular cards.
- **Borders:** All glass containers should feature a 1px inner stroke to simulate light catching the edge of a glass pane.

## Components

### Buttons
- **Primary:** Gradient fill (Teal to Indigo), white text, pill-shaped. Soft teal outer glow on hover.
- **Secondary:** Glass background with white border. Text in #E2E8F0.

### Cards (The Budget Container)
The core component of the design system. Must include:
- `backdrop-filter: blur(16px)`
- `background: rgba(255, 255, 255, 0.05)`
- `border: 1px solid rgba(255, 255, 255, 0.1)`
- Internal padding of 24px.

### Inputs & Selects
- Background: `rgba(0, 0, 0, 0.2)`.
- Border: 1px solid `rgba(255, 255, 255, 0.1)`.
- On focus: Border color changes to Primary Teal (#14B8A6) with a 4px soft glow.
- Corner radius: 12px.

### Chips / Status Tags
- **Income:** Light jade background (15% opacity) with jade text.
- **Expense:** Light coral background (15% opacity) with coral text.
- Rounded: 100px (Pill).

### Progress Bars
- Background: Track is dark navy (`rgba(0,0,0,0.3)`).
- Fill: Gradient of Teal to Indigo. For "Over Budget," use Coral Red.